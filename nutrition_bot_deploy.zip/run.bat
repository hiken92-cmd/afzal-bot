@echo off
chcp 65001 > nul
echo Запуск многофункционального Telegram бота Афзала...
python bot.py
pause

